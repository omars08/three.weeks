#ifndef RECORDEMPLOYEE_H
#define RECORDEMPLOYEE_H


class RecordEmployee
{
    public:
        RecordEmployee();
        void create

    private:
};

#endif // RECORDEMPLOYEE_H
