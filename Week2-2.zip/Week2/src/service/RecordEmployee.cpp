#include "RecordEmployee.h"

RecordEmployee::RecordEmployee()
{
    //ctor
}

RecordEmployee::~RecordEmployee()
{
    //dtor
}
